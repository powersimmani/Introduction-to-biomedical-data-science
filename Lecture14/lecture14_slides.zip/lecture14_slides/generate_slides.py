import os

# Part dividers
parts = [
    {
        "num": "1",
        "title": "Ethics in Biomedical AI",
        "topics": [
            "Principles and values",
            "Practical challenges",
            "Governance frameworks"
        ]
    },
    {
        "num": "2",
        "title": "Regulatory Framework",
        "topics": [
            "Global regulations",
            "Approval pathways",
            "Compliance requirements"
        ]
    },
    {
        "num": "3",
        "title": "Implementation",
        "topics": [
            "Deployment strategies",
            "Change management",
            "Success factors"
        ]
    }
]

# Content slides
content_slides = [
    # Part 1
    {"file": "04", "title": "Beneficence Principles", "items": ["Do no harm", "Patient benefit", "Risk-benefit analysis", "Unintended consequences", "Precautionary principle"]},
    {"file": "05", "title": "Privacy Concerns", "items": ["Data sensitivity", "Re-identification risks", "Genetic privacy", "Family implications", "Data breaches"]},
    {"file": "06", "title": "Informed Consent", "items": ["AI transparency", "Data usage", "Future use provisions", "Withdrawal rights", "Capacity issues"]},
    {"file": "07", "title": "Data Ownership", "items": ["Patient rights", "Institutional claims", "Commercial interests", "Benefit sharing", "Indigenous data"]},
    {"file": "08", "title": "Algorithmic Bias", "items": ["Sources of bias", "Health disparities", "Fairness metrics", "Mitigation strategies", "Continuous monitoring"]},
    {"file": "09", "title": "Health Disparities", "items": ["Digital divide", "Representation gaps", "Access barriers", "Outcome inequities", "Social determinants"]},
    {"file": "10", "title": "Transparency", "items": ["Model explainability", "Decision rationale", "Uncertainty communication", "Audit trails", "Public reporting"]},
    # Part 2
    {"file": "12", "title": "FDA Regulations", "items": ["Software as medical device", "510(k) process", "De novo pathway", "PMA requirements", "Breakthrough designation"]},
    {"file": "13", "title": "CE Marking", "items": ["MDR requirements", "Risk classification", "Clinical evaluation", "Post-market surveillance", "UKCA divergence"]},
    {"file": "14", "title": "Clinical Validation", "items": ["Study design requirements", "Performance standards", "Safety endpoints", "Real-world evidence", "Post-approval studies"]},
    {"file": "15", "title": "Software as Medical Device", "items": ["SaMD framework", "Risk categorization", "Quality management", "Cybersecurity", "Updates and modifications"]},
    {"file": "16", "title": "Quality Management", "items": ["ISO 13485", "Design controls", "Risk management", "Document control", "CAPA systems"]},
    {"file": "17", "title": "Post-market Surveillance", "items": ["Adverse event reporting", "Performance monitoring", "Periodic reviews", "Field corrections", "Recalls"]},
    # Part 3
    {"file": "19", "title": "Clinical Integration", "items": ["Workflow analysis", "System interfaces", "User training", "Pilot testing", "Scalability"]},
    {"file": "20", "title": "Change Management", "items": ["Stakeholder engagement", "Communication plans", "Resistance handling", "Culture change", "Success metrics"]},
    {"file": "21", "title": "Training Requirements", "items": ["User competencies", "Training programs", "Certification", "Ongoing education", "Support systems"]},
    {"file": "22", "title": "Cost-benefit Analysis", "items": ["ROI calculation", "Productivity impacts", "Quality improvements", "Risk reduction", "Indirect benefits"]},
    {"file": "23", "title": "Reimbursement", "items": ["CPT codes", "Coverage decisions", "Evidence requirements", "Pricing strategies", "Value-based contracts"]},
    {"file": "24", "title": "Liability Issues", "items": ["Malpractice considerations", "Product liability", "Insurance coverage", "Indemnification", "Risk allocation"]},
    {"file": "25", "title": "Global Perspectives", "items": ["Regulatory harmonization", "Cross-border data", "Cultural considerations", "International standards", "Collaboration models"]},
    {"file": "26", "title": "Future Regulations", "items": ["AI-specific legislation", "Adaptive regulations", "Sandbox approaches", "International coordination", "Emerging issues"]},
    {"file": "27", "title": "Best Practices", "items": ["Governance structures", "Ethics committees", "Documentation standards", "Audit procedures", "Continuous improvement"]},
    {"file": "28", "title": "Case Studies", "items": ["Success stories", "Failure analysis", "Lessons learned", "Implementation tips", "Regulatory examples"]},
    {"file": "29", "title": "Discussion Scenarios", "items": ["Ethical dilemmas", "Regulatory challenges", "Implementation issues", "Group exercises", "Solution development"]},
]

# Generate Part Dividers
for i, part in enumerate(parts, 1):
    filename = f"Lecture14_{str(i+2).zfill(2)}_Part{part['num']}.html"
    topics_html = '\n            '.join([f'''<div class="topic-item">
                <span class="topic-number">{j}.</span>
                <span>{topic}</span>
            </div>''' for j, topic in enumerate(part['topics'], 1)])
    
    html_content = f'''<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Part {part['num']}: {part['title']}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: Aptos, 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #1E64C8 0%, #5088d4 100%);
        }}
        
        .container {{
            width: 960px;
            height: 540px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 60px;
            color: white;
        }}
        
        .part-label {{
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 30px;
        }}
        
        .part-title {{
            font-size: 44px;
            font-weight: 700;
            margin-bottom: 60px;
            line-height: 1.2;
        }}
        
        .topics-list {{
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-left: 40px;
        }}
        
        .topic-item {{
            font-size: 20px;
            font-weight: 400;
            display: flex;
            align-items: center;
            gap: 16px;
        }}
        
        .topic-number {{
            font-weight: 700;
            width: 40px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="part-label">Part {part['num']}/3:</div>
        <div class="part-title">{part['title']}</div>
        
        <div class="topics-list">
            {topics_html}
        </div>
    </div>
</body>
</html>'''
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"Created {filename}")

# Generate Content Slides
for slide in content_slides:
    filename = f"Lecture14_{slide['file']}_{slide['title'].replace(' ', '_').replace('/', '_')}.html"
    items_html = '\n            '.join([f'''<div class="bullet-item">
                <span class="bullet">•</span>
                <span>{item}</span>
            </div>''' for item in slide['items']])
    
    html_content = f'''<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{slide['title']}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: Aptos, 'Segoe UI', sans-serif;
            background: white;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }}
        
        .container {{
            width: 960px;
            height: 540px;
            padding: 50px 80px;
            background: white;
        }}
        
        .title {{
            font-size: 36px;
            font-weight: 700;
            color: #1E64C8;
            margin-bottom: 40px;
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 3px solid #1E64C8;
        }}
        
        .content-section {{
            display: flex;
            flex-direction: column;
            gap: 18px;
        }}
        
        .bullet-item {{
            display: flex;
            align-items: flex-start;
            gap: 16px;
            padding: 16px 20px;
            background: #f8f9fa;
            border-left: 4px solid #1E64C8;
            border-radius: 8px;
            transition: all 0.3s ease;
        }}
        
        .bullet-item:hover {{
            background: #e8f2ff;
            transform: translateX(8px);
        }}
        
        .bullet {{
            color: #1E64C8;
            font-size: 24px;
            font-weight: bold;
            line-height: 1;
        }}
        
        .bullet-item span:last-child {{
            font-size: 20px;
            color: #333;
            font-weight: 500;
            line-height: 1.4;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="title">{slide['title']}</div>
        
        <div class="content-section">
            {items_html}
        </div>
    </div>
</body>
</html>'''
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"Created {filename}")

print("\nAll slides generated successfully!")
